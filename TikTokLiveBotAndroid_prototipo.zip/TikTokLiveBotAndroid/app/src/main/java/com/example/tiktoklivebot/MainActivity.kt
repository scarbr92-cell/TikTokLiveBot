package com.example.tiktoklivebot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var liveLink: EditText
    private lateinit var command: EditText
    private lateinit var interval: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }

        fun label(value: String) {
            layout.addView(TextView(this).apply {
                text = value
                textSize = 16f
                setPadding(0, 18, 0, 6)
            })
        }
        fun field(hintText: String, value: String = ""): EditText {
            return EditText(this).apply {
                hint = hintText
                setSingleLine(true)
                setText(value)
                textSize = 16f
                layout.addView(this, LinearLayout.LayoutParams(-1, -2))
            }
        }
        layout.addView(TextView(this).apply {
            text = "TikTok Live Bot"
            textSize = 26f
            setPadding(0, 0, 0, 8)
        })
        layout.addView(TextView(this).apply {
            text = "Protótipo Android • integração de chat ainda não disponível"
            textSize = 13f
        })

        label("Link da live")
        liveLink = field("Cole o link da live do TikTok")
        label("Comando")
        command = field("Ex.: !pontos", "!pontos")
        label("Intervalo (segundos)")
        interval = field("Ex.: 60", "60")

        val note = TextView(this).apply {
            text = "IMPORTANTE: esta versão valida e guarda as configurações e mantém um serviço em primeiro plano. Ela NÃO entra na live nem envia mensagens. Não informe sua senha do TikTok."
            textSize = 14f
            setPadding(0, 22, 0, 12)
        }
        layout.addView(note)

        val start = Button(this).apply {
            text = "Iniciar sessão de teste"
            setOnClickListener { startSession() }
        }
        layout.addView(start)

        val stop = Button(this).apply {
            text = "Parar"
            setOnClickListener {
                stopService(Intent(this@MainActivity, BotService::class.java))
                status.text = "Sessão parada."
            }
        }
        layout.addView(stop)

        status = TextView(this).apply {
            text = "Status: parado"
            textSize = 15f
            setPadding(0, 20, 0, 0)
        }
        layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun startSession() {
        val url = liveLink.text.toString().trim()
        val cmd = command.text.toString().trim()
        val seconds = interval.text.toString().toString().toLongOrNull()

        if (!(url.startsWith("https://www.tiktok.com/") ||
              url.startsWith("https://vt.tiktok.com/"))) {
            liveLink.error = "Cole um link válido do TikTok"
            return
        }
        if (cmd.isBlank()) {
            command.error = "Informe o comando"
            return
        }
        if (seconds == null || seconds < 30) {
            interval.error = "Use pelo menos 30 segundos"
            return
        }

        val intent = Intent(this, BotService::class.java).apply {
            putExtra("command", cmd)
            putExtra("interval", seconds)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "Sessão de teste ativa. Nenhuma mensagem será enviada."
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
